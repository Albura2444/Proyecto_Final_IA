# Resultados

Al ejecutar el script o notebook, aqui se guardaran automaticamente:

- `metricas_modelos.csv`
- matriz de confusion del mejor modelo
- grafica de importancia de variables, si aplica
