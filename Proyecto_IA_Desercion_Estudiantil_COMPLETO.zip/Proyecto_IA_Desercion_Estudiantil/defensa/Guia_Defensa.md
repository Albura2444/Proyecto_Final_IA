# Guia para la defensa del proyecto

## 1. Por que eligieron este problema?
Porque la desercion estudiantil afecta al estudiante, a la institucion y al uso eficiente de recursos academicos. Detectar riesgo de abandono permite intervenir antes de que el problema avance.

## 2. Que tipo de problema es?
Es un problema de clasificacion supervisada. El sistema aprende de casos historicos donde ya se conoce si el estudiante abandono o no.

## 3. Por que usaron esos modelos?
- Regresion Logistica: sirve como modelo base, es interpretable y permite comparar.
- Arbol de Decision: permite explicar reglas de decision de forma sencilla.
- Random Forest: combina varios arboles y suele mejorar la estabilidad y el desempeno.

## 4. Como evitaron overfitting?
Se separaron datos de entrenamiento y prueba, se uso validacion cruzada, profundidad limitada en arboles y comparacion de metricas.

## 5. Que metrica importa mas?
Recall y F1-score. En este problema es importante detectar la mayor cantidad posible de estudiantes en riesgo, sin dejar de controlar falsos positivos.

## 6. Que limitaciones tiene?
El modelo depende de la calidad y actualidad de los datos. Tambien puede heredar sesgos si los datos historicos reflejan desigualdades previas.

## 7. Como se usaria responsablemente?
Como alerta temprana para acompanamiento academico, tutorias, apoyo financiero o consejeria. No debe usarse para castigar o excluir estudiantes.

## 8. Que mejorarian?
Integrar datos actualizados de cada ciclo, medir equidad entre grupos, agregar explicabilidad con SHAP y crear un dashboard para seguimiento.
