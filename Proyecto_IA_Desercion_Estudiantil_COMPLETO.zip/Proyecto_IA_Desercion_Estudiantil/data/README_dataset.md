# Dataset

La fuente principal del proyecto es el dataset **Predict Students Dropout and Academic Success** de UCI Machine Learning Repository.

El archivo `student_dropout_sample.csv` es una muestra tecnica incluida solo para que el codigo pueda ejecutarse sin internet y demostrar el flujo del prototipo.

Para una entrega final mas fuerte, ejecutar el notebook con conexion a internet para descargar el dataset real desde UCI usando `ucimlrepo`.
