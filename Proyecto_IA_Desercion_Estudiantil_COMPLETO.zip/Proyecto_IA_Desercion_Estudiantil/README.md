# Proyecto Final - Inteligencia Artificial

## Escenario 4: Prediccion de Desercion Estudiantil

Este repositorio contiene una solucion de Machine Learning para identificar estudiantes con posible riesgo de desercion academica. La solucion usa clasificacion supervisada y compara varios modelos para seleccionar el que ofrece mejor desempeno.

## Objetivo

Desarrollar un prototipo funcional que permita predecir si un estudiante presenta riesgo de abandono academico a partir de variables academicas, demograficas y socioeconomicas.

## Dataset

Fuente principal: **Predict Students' Dropout and Academic Success**, UCI Machine Learning Repository.

El codigo intenta descargar el dataset real desde UCI usando `ucimlrepo`. Si no hay conexion a internet, usa el archivo `data/student_dropout_sample.csv`, que es una muestra tecnica generada para demostrar el flujo del prototipo.

## Modelos implementados

- Regresion Logistica
- Arbol de Decision
- Random Forest

## Metricas utilizadas

- Accuracy
- Precision
- Recall
- F1-score
- ROC-AUC
- Matriz de confusion

## Estructura del repositorio

```text
Proyecto_IA_Desercion_Estudiantil/
├── README.md
├── requirements.txt
├── .gitignore
├── src/
│   └── prototipo_desercion_estudiantil.py
├── notebooks/
│   └── Notebook_IA_Desercion_Estudiantil.ipynb
├── data/
│   ├── README_dataset.md
│   └── student_dropout_sample.csv
├── documentos/
│   ├── Proyecto_Final_IA_Desercion_Estudiantil.docx
│   └── Proyecto_Final_IA_Desercion_Estudiantil.pdf
├── presentacion/
│   └── Presentacion_Proyecto_IA_Desercion_Estudiantil.pptx
├── resultados/
│   └── README_resultados.md
└── defensa/
    └── Guia_Defensa.md
```

## Como ejecutar

1. Crear entorno virtual, si se desea:

```bash
python -m venv .venv
```

2. Activar entorno:

```bash
# Windows
.venv\Scripts\activate

# Mac/Linux
source .venv/bin/activate
```

3. Instalar dependencias:

```bash
pip install -r requirements.txt
```

4. Ejecutar el prototipo:

```bash
python src/prototipo_desercion_estudiantil.py
```

5. Revisar resultados generados en la carpeta:

```text
resultados/
```

## Nota academica

El modelo debe usarse como apoyo para detectar posibles casos de riesgo y activar acciones de acompanamiento. No debe utilizarse como herramienta para excluir, castigar o etiquetar definitivamente a estudiantes.
